package foundationdb

// If you want to use FoundationDB, you must install [client](https://www.foundationdb.org/download/) libraray.
