package sqlite

// If you want to use sqlite, you must install [client](https://www.sqlite.org/download.html) libraray.
